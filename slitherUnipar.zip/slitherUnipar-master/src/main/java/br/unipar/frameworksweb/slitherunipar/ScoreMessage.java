package br.unipar.frameworksweb.slitherunipar;

public class ScoreMessage {
    private String player;
    private int score;

    // Getters e Setters
    public String getPlayer() { return player; }
    public void setPlayer(String player) { this.player = player; }
    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }
}
