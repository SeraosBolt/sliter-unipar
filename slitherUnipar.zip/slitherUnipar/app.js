document.addEventListener("DOMContentLoaded", function () {
    const loginContainer = document.getElementById('login-container');
    const gameContainer = document.getElementById('game-container');
    const restartContainer = document.getElementById('restart-container');
    const connectButton = document.getElementById('connect-button');
    const playerNameInput = document.getElementById('player-name');
    const gameArea = document.getElementById('game-area');
    const restartButton = document.getElementById('restart-button');
    const killCountElement = document.getElementById('kill-count');
    const playerColors = {};
    const botColors = {};
    let loggedInPlayer = null;
    const playerSpeed = 10;
    let killCount = 0;

    const socket = new SockJS('http://localhost:8080/game', {
        headers: {
            'ngrok-skip-browser-warning': 'true'
        }
    });
    const stompClient = Stomp.over(socket);

    stompClient.connect({}, function (frame) {
        console.log('Connected: ' + frame);
        const playerName = playerNameInput.value.trim();
        stompClient.subscribe('/topic/game', function (response) {
            const data = JSON.parse(response.body);
            updateGameState(data, gameArea, loggedInPlayer, playerColors, botColors);
            killCountElement.innerText = data.score.filter(elem => {
                return elem.player.trim() == loggedInPlayer.name
            })[0].score
            killCount = data.score.filter(elem => {
                return elem.player.trim() == loggedInPlayer.name
            })[0].score
            

        });
    });

    connectButton.addEventListener('click', function () {
        const playerName = playerNameInput.value.trim();

        if (playerName) {
            stompClient.send("/app/connect", {}, JSON.stringify({ name: playerName }));
            loggedInPlayer = { name: playerName, position: { x: 0, y: 0 } };
            loginContainer.style.display = 'none';
            gameContainer.style.display = 'block';
            restartContainer.style.display = 'none';
        } else {
            alert('Please enter a player name.');
        }
    });

    restartButton.addEventListener('click', function () {
        loginContainer.style.display = 'block';
        gameContainer.style.display = 'none';
        restartContainer.style.display = 'none';
        loggedInPlayer = null;
    });

    document.addEventListener('keydown', function (event) {
        if (!loggedInPlayer) return;
        console.log('Player Position Before Move:', loggedInPlayer.position); // Debug

        switch (event.key) {
            case 'ArrowUp':
                loggedInPlayer.position.y -= playerSpeed;
                break;
            case 'ArrowDown':
                loggedInPlayer.position.y += playerSpeed;
                break;
            case 'ArrowLeft':
                loggedInPlayer.position.x -= playerSpeed;
                break;
            case 'ArrowRight':
                loggedInPlayer.position.x += playerSpeed;
                break;
        }

        console.log('Player Position After Move:', loggedInPlayer.position); // Debug

        updatePlayerPosition(loggedInPlayer);

        if (loggedInPlayer && stompClient) {
            var move = {
                name: loggedInPlayer.name,
                position: loggedInPlayer.position,
                score: killCount
            };

            console.log('Enviando nova posição: ', move);
            stompClient.send("/app/move", {}, JSON.stringify(move));
        }
    });

    function getGameAreaDimensions() {
        return {
            width: window.innerWidth,
            height: window.innerHeight
        };
    }

    function showRestartScreen() {
        gameContainer.style.display = 'none';
        restartContainer.style.display = 'flex';
    }

    function simulatePlayerDeath() {
        showRestartScreen();
    }

    function onPlayerDeath() {
        simulatePlayerDeath();
    }


});

function updatePlayerPosition(player) {
    const playerElement = document.querySelector(`[data-player-name="${player.name}"]`);
    if (playerElement) {
        playerElement.style.left = `${player.position.x}px`;
        playerElement.style.top = `${player.position.y}px`;
    }
}

function updateGameState(data, gameArea, loggedInPlayer, playerColors, botColors) {
    gameArea.innerHTML = '';

    data.players.forEach(player => {
        const playerElement = document.createElement('div');
        playerElement.textContent = `${player.name}`;
        playerElement.classList.add('player');
        playerElement.setAttribute('data-player-name', player.name);
        playerElement.style.left = `${player.position.x}px`;
        playerElement.style.top = `${player.position.y}px`;
        playerElement.style.backgroundColor = getOrCreateColor(player.name, playerColors);
        gameArea.appendChild(playerElement);

        if (player.name === loggedInPlayer.name) {
            loggedInPlayer.position = player.position;
            if (player.dead) {
                onPlayerDeath();
            }
        }
    });

    data.bots.forEach(bot => {
        const botElement = document.createElement('div');
        botElement.textContent = `${bot.name}`;
        botElement.classList.add('bot');
        botElement.setAttribute('data-bot-name', bot.name);
        botElement.style.left = `${bot.position.x}px`;
        botElement.style.top = `${bot.position.y}px`;
        botElement.style.backgroundColor = getOrCreateColor(bot.name, botColors);
        gameArea.appendChild(botElement);

    });
}

function getOrCreateColor(id, colorStorage) {
    if (!colorStorage[id]) {
        colorStorage[id] = generateRandomColor();
    }
    return colorStorage[id];
}

function generateRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}
